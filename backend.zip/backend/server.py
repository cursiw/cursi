from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
import bcrypt
import jwt
from enum import Enum

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT Configuration
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key-change-in-production')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION = 7  # days

security = HTTPBearer()

# Create the main app
app = FastAPI()
api_router = APIRouter(prefix="/api")

# Enums
class TournamentStatus(str, Enum):
    upcoming = "upcoming"
    ongoing = "ongoing"
    completed = "completed"
    cancelled = "cancelled"

class TournamentFormat(str, Enum):
    single_elimination = "single_elimination"
    double_elimination = "double_elimination"
    round_robin = "round_robin"

class MatchStatus(str, Enum):
    pending = "pending"
    ongoing = "ongoing"
    completed = "completed"

class ChallengeStatus(str, Enum):
    pending = "pending"
    accepted = "accepted"
    rejected = "rejected"
    completed = "completed"

class GuildRole(str, Enum):
    leader = "leader"
    officer = "officer"
    member = "member"

# Models
class UserCreate(BaseModel):
    email: EmailStr
    password: str
    username: str
    ign: Optional[str] = None  # In-Game Name

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: str
    username: str
    ign: Optional[str] = None
    guild_id: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    stats: Dict[str, Any] = Field(default_factory=lambda: {
        "tournaments_played": 0,
        "tournaments_won": 0,
        "matches_played": 0,
        "matches_won": 0
    })

class GuildCreate(BaseModel):
    name: str
    tag: str
    description: Optional[str] = None
    logo_url: Optional[str] = None

class GuildMember(BaseModel):
    user_id: str
    username: str
    role: GuildRole
    joined_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Guild(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    tag: str
    description: Optional[str] = None
    logo_url: Optional[str] = None
    leader_id: str
    members: List[GuildMember] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    stats: Dict[str, Any] = Field(default_factory=lambda: {
        "gvg_wins": 0,
        "gvg_losses": 0,
        "tournaments_won": 0,
        "total_points": 0
    })

class TournamentCreate(BaseModel):
    name: str
    description: Optional[str] = None
    format: TournamentFormat
    max_teams: int
    start_date: datetime
    entry_fee: Optional[int] = 0
    prize_pool: Optional[int] = 0
    rules: Optional[str] = None

class TournamentTeam(BaseModel):
    guild_id: str
    guild_name: str
    guild_tag: str
    registered_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Tournament(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    description: Optional[str] = None
    format: TournamentFormat
    status: TournamentStatus = TournamentStatus.upcoming
    max_teams: int
    teams: List[TournamentTeam] = Field(default_factory=list)
    start_date: datetime
    end_date: Optional[datetime] = None
    entry_fee: int = 0
    prize_pool: int = 0
    rules: Optional[str] = None
    organizer_id: str
    winner_id: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class MatchCreate(BaseModel):
    tournament_id: str
    team1_id: str
    team2_id: str
    round: int
    scheduled_time: Optional[datetime] = None

class MatchResult(BaseModel):
    team1_score: int
    team2_score: int
    winner_id: str
    screenshot_url: Optional[str] = None

class Match(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    tournament_id: str
    team1_id: str
    team1_name: str
    team2_id: str
    team2_name: str
    round: int
    status: MatchStatus = MatchStatus.pending
    scheduled_time: Optional[datetime] = None
    team1_score: Optional[int] = None
    team2_score: Optional[int] = None
    winner_id: Optional[str] = None
    screenshot_url: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ChallengeCreate(BaseModel):
    defender_guild_id: str
    message: Optional[str] = None
    wager: Optional[int] = 0

class Challenge(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    challenger_guild_id: str
    challenger_guild_name: str
    defender_guild_id: str
    defender_guild_name: str
    status: ChallengeStatus = ChallengeStatus.pending
    message: Optional[str] = None
    wager: int = 0
    match_id: Optional[str] = None
    winner_id: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class NotificationCreate(BaseModel):
    user_id: str
    title: str
    message: str
    type: str

class Notification(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    title: str
    message: str
    type: str
    read: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# Helper Functions
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))

def create_token(user_id: str) -> str:
    payload = {
        'user_id': user_id,
        'exp': datetime.now(timezone.utc) + timedelta(days=JWT_EXPIRATION)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    try:
        token = credentials.credentials
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = payload.get('user_id')
        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid token")
        user = await db.users.find_one({'id': user_id}, {'_id': 0, 'password': 0})
        if not user:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

# Root route
@api_router.get("/")
async def root():
    return {"message": "FF Arena API"}

# Auth Routes
@api_router.post("/auth/register")
async def register(user_data: UserCreate):
    existing = await db.users.find_one({'email': user_data.email})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    user = User(
        email=user_data.email,
        username=user_data.username,
        ign=user_data.ign
    )
    
    doc = user.model_dump()
    doc['password'] = hash_password(user_data.password)
    doc['created_at'] = doc['created_at'].isoformat()
    
    await db.users.insert_one(doc)
    token = create_token(user.id)
    
    return {'token': token, 'user': user}

@api_router.post("/auth/login")
async def login(credentials: UserLogin):
    user = await db.users.find_one({'email': credentials.email})
    if not user or not verify_password(credentials.password, user['password']):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    token = create_token(user['id'])
    user_data = {k: v for k, v in user.items() if k not in ['_id', 'password']}
    
    return {'token': token, 'user': user_data}

@api_router.get("/auth/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    return current_user

# Guild Routes
@api_router.post("/guilds", response_model=Guild)
async def create_guild(guild_data: GuildCreate, current_user: dict = Depends(get_current_user)):
    if current_user.get('guild_id'):
        raise HTTPException(status_code=400, detail="You are already in a guild")
    
    existing = await db.guilds.find_one({'tag': guild_data.tag})
    if existing:
        raise HTTPException(status_code=400, detail="Guild tag already taken")
    
    guild = Guild(
        name=guild_data.name,
        tag=guild_data.tag,
        description=guild_data.description,
        logo_url=guild_data.logo_url,
        leader_id=current_user['id'],
        members=[GuildMember(
            user_id=current_user['id'],
            username=current_user['username'],
            role=GuildRole.leader
        )]
    )
    
    doc = guild.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    for member in doc['members']:
        member['joined_at'] = member['joined_at'].isoformat()
    
    await db.guilds.insert_one(doc)
    await db.users.update_one({'id': current_user['id']}, {'$set': {'guild_id': guild.id}})
    
    return guild

@api_router.get("/guilds", response_model=List[Guild])
async def get_guilds():
    guilds = await db.guilds.find({}, {'_id': 0}).to_list(1000)
    for guild in guilds:
        if isinstance(guild.get('created_at'), str):
            guild['created_at'] = datetime.fromisoformat(guild['created_at'])
        for member in guild.get('members', []):
            if isinstance(member.get('joined_at'), str):
                member['joined_at'] = datetime.fromisoformat(member['joined_at'])
    return guilds

@api_router.get("/guilds/{guild_id}", response_model=Guild)
async def get_guild(guild_id: str):
    guild = await db.guilds.find_one({'id': guild_id}, {'_id': 0})
    if not guild:
        raise HTTPException(status_code=404, detail="Guild not found")
    
    if isinstance(guild.get('created_at'), str):
        guild['created_at'] = datetime.fromisoformat(guild['created_at'])
    for member in guild.get('members', []):
        if isinstance(member.get('joined_at'), str):
            member['joined_at'] = datetime.fromisoformat(member['joined_at'])
    
    return guild

@api_router.post("/guilds/{guild_id}/join")
async def join_guild(guild_id: str, current_user: dict = Depends(get_current_user)):
    if current_user.get('guild_id'):
        raise HTTPException(status_code=400, detail="You are already in a guild")
    
    guild = await db.guilds.find_one({'id': guild_id})
    if not guild:
        raise HTTPException(status_code=404, detail="Guild not found")
    
    new_member = GuildMember(
        user_id=current_user['id'],
        username=current_user['username'],
        role=GuildRole.member
    )
    
    member_dict = new_member.model_dump()
    member_dict['joined_at'] = member_dict['joined_at'].isoformat()
    
    await db.guilds.update_one(
        {'id': guild_id},
        {'$push': {'members': member_dict}}
    )
    await db.users.update_one({'id': current_user['id']}, {'$set': {'guild_id': guild_id}})
    
    return {'message': 'Joined guild successfully'}

@api_router.delete("/guilds/{guild_id}/leave")
async def leave_guild(guild_id: str, current_user: dict = Depends(get_current_user)):
    guild = await db.guilds.find_one({'id': guild_id})
    if not guild:
        raise HTTPException(status_code=404, detail="Guild not found")
    
    if guild['leader_id'] == current_user['id']:
        raise HTTPException(status_code=400, detail="Leader cannot leave. Transfer leadership first.")
    
    await db.guilds.update_one(
        {'id': guild_id},
        {'$pull': {'members': {'user_id': current_user['id']}}}
    )
    await db.users.update_one({'id': current_user['id']}, {'$set': {'guild_id': None}})
    
    return {'message': 'Left guild successfully'}

# Tournament Routes
@api_router.post("/tournaments", response_model=Tournament)
async def create_tournament(tournament_data: TournamentCreate, current_user: dict = Depends(get_current_user)):
    tournament = Tournament(
        **tournament_data.model_dump(),
        organizer_id=current_user['id']
    )
    
    doc = tournament.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    doc['start_date'] = doc['start_date'].isoformat()
    if doc.get('end_date'):
        doc['end_date'] = doc['end_date'].isoformat()
    for team in doc.get('teams', []):
        team['registered_at'] = team['registered_at'].isoformat()
    
    await db.tournaments.insert_one(doc)
    return tournament

@api_router.get("/tournaments", response_model=List[Tournament])
async def get_tournaments(status: Optional[TournamentStatus] = None):
    query = {'status': status} if status else {}
    tournaments = await db.tournaments.find(query, {'_id': 0}).to_list(1000)
    
    for tournament in tournaments:
        if isinstance(tournament.get('created_at'), str):
            tournament['created_at'] = datetime.fromisoformat(tournament['created_at'])
        if isinstance(tournament.get('start_date'), str):
            tournament['start_date'] = datetime.fromisoformat(tournament['start_date'])
        if tournament.get('end_date') and isinstance(tournament['end_date'], str):
            tournament['end_date'] = datetime.fromisoformat(tournament['end_date'])
        for team in tournament.get('teams', []):
            if isinstance(team.get('registered_at'), str):
                team['registered_at'] = datetime.fromisoformat(team['registered_at'])
    
    return tournaments

@api_router.get("/tournaments/{tournament_id}", response_model=Tournament)
async def get_tournament(tournament_id: str):
    tournament = await db.tournaments.find_one({'id': tournament_id}, {'_id': 0})
    if not tournament:
        raise HTTPException(status_code=404, detail="Tournament not found")
    
    if isinstance(tournament.get('created_at'), str):
        tournament['created_at'] = datetime.fromisoformat(tournament['created_at'])
    if isinstance(tournament.get('start_date'), str):
        tournament['start_date'] = datetime.fromisoformat(tournament['start_date'])
    if tournament.get('end_date') and isinstance(tournament['end_date'], str):
        tournament['end_date'] = datetime.fromisoformat(tournament['end_date'])
    for team in tournament.get('teams', []):
        if isinstance(team.get('registered_at'), str):
            team['registered_at'] = datetime.fromisoformat(team['registered_at'])
    
    return tournament

@api_router.post("/tournaments/{tournament_id}/register")
async def register_tournament(tournament_id: str, current_user: dict = Depends(get_current_user)):
    if not current_user.get('guild_id'):
        raise HTTPException(status_code=400, detail="You must be in a guild to register")
    
    tournament = await db.tournaments.find_one({'id': tournament_id})
    if not tournament:
        raise HTTPException(status_code=404, detail="Tournament not found")
    
    if tournament['status'] != 'upcoming':
        raise HTTPException(status_code=400, detail="Tournament registration is closed")
    
    if len(tournament.get('teams', [])) >= tournament['max_teams']:
        raise HTTPException(status_code=400, detail="Tournament is full")
    
    guild = await db.guilds.find_one({'id': current_user['guild_id']})
    if not guild:
        raise HTTPException(status_code=404, detail="Guild not found")
    
    # Check if guild already registered
    for team in tournament.get('teams', []):
        if team['guild_id'] == guild['id']:
            raise HTTPException(status_code=400, detail="Guild already registered")
    
    new_team = TournamentTeam(
        guild_id=guild['id'],
        guild_name=guild['name'],
        guild_tag=guild['tag']
    )
    
    team_dict = new_team.model_dump()
    team_dict['registered_at'] = team_dict['registered_at'].isoformat()
    
    await db.tournaments.update_one(
        {'id': tournament_id},
        {'$push': {'teams': team_dict}}
    )
    
    return {'message': 'Registered successfully'}

# Match Routes
@api_router.get("/matches", response_model=List[Match])
async def get_matches(tournament_id: Optional[str] = None):
    query = {'tournament_id': tournament_id} if tournament_id else {}
    matches = await db.matches.find(query, {'_id': 0}).to_list(1000)
    
    for match in matches:
        if isinstance(match.get('created_at'), str):
            match['created_at'] = datetime.fromisoformat(match['created_at'])
        if match.get('scheduled_time') and isinstance(match['scheduled_time'], str):
            match['scheduled_time'] = datetime.fromisoformat(match['scheduled_time'])
    
    return matches

@api_router.get("/matches/{match_id}", response_model=Match)
async def get_match(match_id: str):
    match = await db.matches.find_one({'id': match_id}, {'_id': 0})
    if not match:
        raise HTTPException(status_code=404, detail="Match not found")
    
    if isinstance(match.get('created_at'), str):
        match['created_at'] = datetime.fromisoformat(match['created_at'])
    if match.get('scheduled_time') and isinstance(match['scheduled_time'], str):
        match['scheduled_time'] = datetime.fromisoformat(match['scheduled_time'])
    
    return match

@api_router.post("/matches/{match_id}/result")
async def submit_match_result(match_id: str, result: MatchResult, current_user: dict = Depends(get_current_user)):
    match = await db.matches.find_one({'id': match_id})
    if not match:
        raise HTTPException(status_code=404, detail="Match not found")
    
    tournament = await db.tournaments.find_one({'id': match['tournament_id']})
    if not tournament:
        raise HTTPException(status_code=404, detail="Tournament not found")
    if current_user['id'] != tournament['organizer_id']:
        raise HTTPException(status_code=403, detail="Not authorized to submit results")
    if result.winner_id not in [match['team1_id'], match['team2_id']]:
        raise HTTPException(status_code=400, detail="Invalid winner")
    
    update_data = {
        'team1_score': result.team1_score,
        'team2_score': result.team2_score,
        'winner_id': result.winner_id,
        'status': MatchStatus.completed
    }
    
    if result.screenshot_url:
        update_data['screenshot_url'] = result.screenshot_url
    
    await db.matches.update_one({'id': match_id}, {'$set': update_data})
    
    return {'message': 'Match result submitted'}

# GVG Challenge Routes
@api_router.post("/challenges", response_model=Challenge)
async def create_challenge(challenge_data: ChallengeCreate, current_user: dict = Depends(get_current_user)):
    if not current_user.get('guild_id'):
        raise HTTPException(status_code=400, detail="You must be in a guild to create challenges")
    
    challenger_guild = await db.guilds.find_one({'id': current_user['guild_id']})
    if not challenger_guild:
        raise HTTPException(status_code=404, detail="Your guild not found")
    
    defender_guild = await db.guilds.find_one({'id': challenge_data.defender_guild_id})
    if not defender_guild:
        raise HTTPException(status_code=404, detail="Defender guild not found")
    
    if challenge_data.defender_guild_id == current_user['guild_id']:
        raise HTTPException(status_code=400, detail="Cannot challenge your own guild")
    
    challenge = Challenge(
        challenger_guild_id=challenger_guild['id'],
        challenger_guild_name=challenger_guild['name'],
        defender_guild_id=defender_guild['id'],
        defender_guild_name=defender_guild['name'],
        message=challenge_data.message,
        wager=challenge_data.wager or 0
    )
    
    doc = challenge.model_dump()
    doc['created_at'] = doc['created_at'].isoformat()
    
    await db.challenges.insert_one(doc)
    return challenge

@api_router.get("/challenges", response_model=List[Challenge])
async def get_challenges(guild_id: Optional[str] = None):
    query = {}
    if guild_id:
        query = {'$or': [{'challenger_guild_id': guild_id}, {'defender_guild_id': guild_id}]}
    
    challenges = await db.challenges.find(query, {'_id': 0}).to_list(1000)
    
    for challenge in challenges:
        if isinstance(challenge.get('created_at'), str):
            challenge['created_at'] = datetime.fromisoformat(challenge['created_at'])
    
    return challenges

@api_router.post("/challenges/{challenge_id}/accept")
async def accept_challenge(challenge_id: str, current_user: dict = Depends(get_current_user)):
    challenge = await db.challenges.find_one({'id': challenge_id})
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found")
    
    if current_user.get('guild_id') != challenge['defender_guild_id']:
        raise HTTPException(status_code=403, detail="Only defender guild can accept")
    
    await db.challenges.update_one(
        {'id': challenge_id},
        {'$set': {'status': ChallengeStatus.accepted}}
    )
    
    return {'message': 'Challenge accepted'}

@api_router.post("/challenges/{challenge_id}/reject")
async def reject_challenge(challenge_id: str, current_user: dict = Depends(get_current_user)):
    challenge = await db.challenges.find_one({'id': challenge_id})
    if not challenge:
        raise HTTPException(status_code=404, detail="Challenge not found")
    
    if current_user.get('guild_id') != challenge['defender_guild_id']:
        raise HTTPException(status_code=403, detail="Only defender guild can reject")
    
    await db.challenges.update_one(
        {'id': challenge_id},
        {'$set': {'status': ChallengeStatus.rejected}}
    )
    
    return {'message': 'Challenge rejected'}

# Notification Routes
@api_router.get("/notifications", response_model=List[Notification])
async def get_notifications(current_user: dict = Depends(get_current_user)):
    notifications = await db.notifications.find(
        {'user_id': current_user['id']},
        {'_id': 0}
    ).sort('created_at', -1).to_list(100)
    
    for notif in notifications:
        if isinstance(notif.get('created_at'), str):
            notif['created_at'] = datetime.fromisoformat(notif['created_at'])
    
    return notifications

@api_router.post("/notifications/{notification_id}/read")
async def mark_notification_read(notification_id: str, current_user: dict = Depends(get_current_user)):
    await db.notifications.update_one(
        {'id': notification_id, 'user_id': current_user['id']},
        {'$set': {'read': True}}
    )
    return {'message': 'Notification marked as read'}

# Leaderboard Route
@api_router.get("/leaderboard/guilds")
async def get_guild_leaderboard():
    guilds = await db.guilds.find({}, {'_id': 0}).to_list(1000)
    sorted_guilds = sorted(guilds, key=lambda g: g.get('stats', {}).get('total_points', 0), reverse=True)
    return sorted_guilds[:50]

# Include router
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
